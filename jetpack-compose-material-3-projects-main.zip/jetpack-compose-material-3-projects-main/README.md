# Jetpack Compose Material 3 Projects 

### Chat App UI
<p align="center">
<img src="images/banner.png">
</p>

### Starbucks App UI
<p align="center">
<img src="images/starbucks.png">
</p>

### Furniture App UI
<p align="center">
<img src="images/furniture.png">
</p>
